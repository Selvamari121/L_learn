package com.weather.weatherproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherprojectApplication.class, args);
	}

}
