package com.weather.weatherproject.service;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
@Service
public class WeatherService {
   private RestTemplate restTemplate = new RestTemplate();
   
   private final String apiKey = "4007f5f7c99c4151b8e43345240508";

   public WeatherService(RestTemplateBuilder restTemplateBuilder) {
      this.restTemplate = restTemplateBuilder.build();
   }

   //https://api.weatherapi.com/v1/forecast.json?key=%204007f5f7c99c4151b8e43345240508&q=London
   public String getCurrentWeather(String city) {
      String url = "https://api.weatherapi.com/v1/current.json?key=" + apiKey + "&q=" + city;
      return restTemplate.getForObject(url, String.class);
   } 

  //https://api.weatherapi.com/v1/forecast.json?key=%204007f5f7c99c4151b8e43345240508&q=London&days=2 

   public String getDaylyForecast(String city,int days){
      String url = "http://api.weatherapi.com/v1/forecast.json?key=" + apiKey + "&q=" + city + "&days=" + days;
      return restTemplate.getForObject(url, String.class);
   }

  // https://api.weatherapi.com/v1/forecast.json?key=4007f5f7c99c4151b8e43345240508&q=London&days=1&hour=10

   public String getHourlyForecast(String city,int days,int hour){
      String url = "http://api.weatherapi.com/v1/forecast.json?key=" + apiKey + "&q=" + city+ "&days=" + days + "&hour=" + hour;
      return restTemplate.getForObject(url, String.class);
   }

   //https://api.weatherapi.com/v1/forecast.json?key=%204007f5f7c99c4151b8e43345240508&q=London&days=2&alerts=no or yes

   public String getAlerts(String city,int days,String alerts){
      String url = "http://api.weatherapi.com/v1/forecast.json?key=" + apiKey + "&q=" + city+ "&days=" + days + "&alerts=" + alerts;
      return restTemplate.getForObject(url, String.class);
   }

   //http://api.weatherapi.com/v1/history.json?key= 4007f5f7c99c4151b8e43345240508&q=London&dt=2023-10-23 --yyyy-mm-dd

   public String getHistoryWeather(String city, String dt) {
      String url = "http://api.weatherapi.com/v1/history.json?key=" + apiKey + "&q=" + city + "&dt=" + dt;
      return restTemplate.getForObject(url, String.class);
   }

}
