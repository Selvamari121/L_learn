document.getElementById('submit').addEventListener('click', async function(e) {
   e.preventDefault();
   const city = document.getElementById('city').value;
   const weatherResult = document.getElementById('weather-result');
   weatherResult.innerHTML = '';

    try {
        const response = await fetch(`/current?city=${city}`);
        if (response.ok) {
            const data = await response.json();
            weatherResult.innerHTML = `
               <h2>Weather in ${data.location.name}</h2>
               <p>Temperature: ${data.current.temp_c}°C</p>
               <p>Condition: ${data.current.condition.text}</p>
               <p>Humidity: ${data.current.humidity}%</p>
               <p>Cloud: ${data.current.cloud}%</p>
           `;
        } else {
           const errorText = await response.text();
           weatherResult.innerHTML = `<p>Failed to fetch weather data: ${errorText}</p>`;
        }
    } catch (error) {
       console.error('Error fetching weather data:', error);
       weatherResult.innerHTML = `<p>Error fetching weather data: ${error.message}</p>`;
    }
});

document.getElementById('dailyForecastBtn').addEventListener('click', function() {
   const dailyForecast = document.getElementById('dailyForecast');
   dailyForecast.style.display = dailyForecast.style.display === 'none' || dailyForecast.style.display === '' ? 'block' : 'none';
});

// document.getElementById('hourlyForecastBtn').addEventListener('click', function() {
//    const hourlyForecast = document.getElementById('hourlyForecast');
//    hourlyForecast.style.display = hourlyForecast.style.display === 'none' || hourlyForecast.style.display === '' ? 'block' : 'none';
// });

// document.getElementById('alertForecastBtn').addEventListener('click', function() {
//    const alertForecast = document.getElementById('alertForecast');
//    alertForecast.style.display = alertForecast.style.display === 'none' || alertForecast.style.display === '' ? 'block' : 'none';
// });

document.getElementById('dailySubmit').addEventListener('click', async function() {
   const city = document.getElementById('city').value;
   const days = document.getElementById('days').value;
   const dailyWeatherResult = document.getElementById('daily-weather-result');
   dailyWeatherResult.innerHTML = '';

   try {
       const response = await fetch(`/dailyforecast?city=${city}&days=${days}`);
       if (response.ok) {
           const data = await response.json();
           dailyWeatherResult.innerHTML = '';
           data.forecast.forecastday.forEach(day => {
               dailyWeatherResult.innerHTML += `
                   <h2>Weather on ${day.date}</h2>
                   <p>Temperature: ${day.day.avgtemp_c}°C</p>
                   <p>WindSpeed: ${day.day.maxwind_kph}kph</p>
                   <p>Humidity: ${day.day.avghumidity}%</p>
               `;
           });
        createchart(data, 'line');
       } else {
           const error = await response.text();
           dailyWeatherResult.innerHTML = `<p>Failed to fetch daily weather data: ${error}</p>`;
       }
   } catch (error) {
       console.error('Error fetching daily weather data:', error);
       dailyWeatherResult.innerHTML = `<p>Error fetching daily weather data: ${error.message}</p>`;
   }
});
const ctx = document.getElementById('myChart').getContext('2d');
function createchart(data, type) {
   const days = data.forecast.forecastday.map(day => day.date);
   const temp_c = data.forecast.forecastday.map(day => day.day.avgtemp_c);
   const wind= data.forecast.forecastday.map(day => day.day.maxwind_kph);
   const humidity = data.forecast.forecastday.map(day => day.day.avghumidity);

   new Chart(ctx, {
       type: type,
       data: {
           labels: days,
           datasets: [{
            label: 'Temperature (°C)',
            data: temp_c,
            borderColor: '#ff1a1a',
            backgroundColor: '#ff0000',
            borderWidth: 1
        },
        {
            label: 'WindSpeed (km/h)',
            data: wind,
            borderColor: '#79ff4d',
            backgroundColor: '#79ff4d',
            borderWidth: 1
        },
        {
            label: 'Humidity (%)',
            data: humidity,
            borderColor: '#1a75ff',
            backgroundColor: ' #0066ff',
            borderWidth: 1
        },]
       },
       options: {
           scales: {
               y: {
                   beginAtZero: true
               }
           }
       }
   });
}
