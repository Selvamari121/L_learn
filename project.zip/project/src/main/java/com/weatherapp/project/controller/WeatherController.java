package com.weatherapp.project.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.weatherapp.project.service.WeatherService;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@RestController
public class WeatherController {
    @Autowired
    private WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @RequestMapping(value = "/")
    public void redirect(HttpServletResponse response) throws IOException {
        response.sendRedirect("index.html");
    }

    @GetMapping("/current")
    public ResponseEntity<String> getCurrentWeather(@RequestParam String city) {
        try {
            String weatherData = weatherService.getCurrentWeather(city);
            return new ResponseEntity<>(weatherData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Server error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }   
    @GetMapping("/dailyforecast")
    public ResponseEntity<String> getDailyForecast(@RequestParam String city, @RequestParam int days) {
        try {
            String forecastData = weatherService.getDaylyForecast(city, days);
            return new ResponseEntity<>(forecastData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Server error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
   
    @GetMapping("/hourlyforecast")
    public ResponseEntity<String> getHourlyForecast(@RequestParam String city,@RequestParam int days) {
        try {
            String forecastData = weatherService.getHourlyForecast(city,days);
            return new ResponseEntity<>(forecastData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Server error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/alerts")
    public ResponseEntity<String> getAlerts(@RequestParam String city, @RequestParam int days, @RequestParam String alerts) {
        try {
           String alertData = weatherService.getAlerts(city, days, alerts);
            return new ResponseEntity<>(alertData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Server error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/history")
    public ResponseEntity<String> getHistoryWeather(@RequestParam String city, @RequestParam String dt) {
        try {
            String historyData = weatherService.getHistoryWeather(city, dt);
            return new ResponseEntity<>(historyData, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("Server error: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



