package com.weatherapp.project.error;

public class GlobalException extends Exception {

}
