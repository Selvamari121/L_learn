package com.weatherapp.project.model;

public class CurrentWeather {
   // private String city;
   // private int days;
   // private int hour;
   // private String alerts;
   // private String dt;

   // public String getDt() {
   //    return dt;
   // }
   // public void setDt(String dt) {
   //    this.dt = dt;
   // }
   // public int getDays() {
   //    return days;
   // }
   // public void setDays(int days) {
   //    this.days = days;
   // }
   // public int getHours() {
   //    return hour;
   // }
   // public void setHours(int hour) {
   //    this.hour = hour;
   // }
   // public String getAlerts() {
   //    return alerts;
   // }
   // public void setAlerts(String alerts) {
   //    this.alerts = alerts;
   // }
   // public String getCity() {
   //    return city;
   // }
   // public void setCity(String city) {
   //    this.city = city;
   // }
}
