document.getElementById('submit').addEventListener('click', async function(e) {
   e.preventDefault();
   const city = document.getElementById('city').value;
   const weatherResult = document.getElementById('weather-result');
   weatherResult.innerHTML = '';

    try {
        const response = await fetch(`/current?city=${city}`);
        if (response.ok) {
            const data = await response.json();
            weatherResult.innerHTML = `
               <h2>Weather in ${data.location.name}</h2>
               <p>Temperature: ${data.current.temp_c}°C</p>
               <p>Condition: ${data.current.condition.text}</p>
               <p>Humidity: ${data.current.humidity}%</p>
               <p>Cloud: ${data.current.cloud}%</p>
           `;
        } else {
           const errorText = await response.text();
           weatherResult.innerHTML = `<p>Failed to fetch weather data: ${errorText}</p>`;
        }
    } catch (error) {
       console.error('Error fetching weather data:', error);
       weatherResult.innerHTML = `<p>Error fetching weather data: ${error.message}</p>`;
    }
});

document.getElementById('dailyForecastBtn').addEventListener('click', function() {
   const dailyForecast = document.getElementById('dailyForecast');
   dailyForecast.style.display = dailyForecast.style.display === 'none' || dailyForecast.style.display === '' ? 'block' : 'none';
});

document.getElementById('hourlyForecastBtn').addEventListener('click', function() {
   const hourlyForecast = document.getElementById('hourlyForecast');
   hourlyForecast.style.display = hourlyForecast.style.display === 'none' || hourlyForecast.style.display === '' ? 'block' : 'none';
});

document.getElementById('alertForecastBtn').addEventListener('click', function() {
   const alertForecast = document.getElementById('alertForecast');
   alertForecast.style.display = alertForecast.style.display === 'none' || alertForecast.style.display === '' ? 'block' : 'none';
});

document.getElementById('weatherHistoryBtn').addEventListener('click', function() {
   const weatherHistory = document.getElementById('weatherHistory');
   weatherHistory.style.display = weatherHistory.style.display === 'none' || weatherHistory.style.display === '' ? 'block' : 'none';
});
document.getElementById('dailySubmit').addEventListener('click', async function() {
    const city = document.getElementById('city').value;
    const days = document.getElementById('days').value;
    const dailyWeatherResult = document.getElementById('daily-weather-result');
    dailyWeatherResult.innerHTML = '';
 
    try {
        const response = await fetch(`/dailyforecast?city=${city}&days=${days}`);
        if (response.ok) {
            const data = await response.json();
            dailyWeatherResult.innerHTML = '';
            data.forecast.forecastday.forEach(day => {
                dailyWeatherResult.innerHTML += `
                    <h2>Weather on ${day.date}</h2>
                    <p>Temperature: ${day.day.avgtemp_c}°C</p>
                    <p>WindSpeed: ${day.day.maxwind_kph}kph</p>
                    <p>Humidity: ${day.day.avghumidity}%</p>
                `;
            });
            createchart(data, 'line');
        } else {
            const error = await response.text();
            dailyWeatherResult.innerHTML = `<p>Failed to fetch daily weather data: ${error}</p>`;
        }
    } catch (error) {
        console.error('Error fetching daily weather data:', error);
        dailyWeatherResult.innerHTML = `<p>Error fetching daily weather data: ${error.message}</p>`;
    }
 });
 const ctx = document.getElementById('myChart');
 function createchart(data, type) {
    const days = data.forecast.forecastday.map(day => day.date);
    const temp_c = data.forecast.forecastday.map(day => day.day.avgtemp_c);
    const wind = data.forecast.forecastday.map(day => day.day.maxwind_kph);
    const humidity = data.forecast.forecastday.map(day => day.day.avghumidity);
 
    new Chart(ctx, {
        type: type,
        data: {
            labels: days,
            datasets: [{
                label: 'Temperature (°C)',
                data: temp_c,
                borderColor: '#ff1a1a',
                backgroundColor: '#ff0000',
                borderWidth: 1
            },
            {
                label: 'WindSpeed (km/h)',
                data: wind,
                borderColor: '#79ff4d',
                backgroundColor: '#79ff4d',
                borderWidth: 1
            },
            {
                label: 'Humidity (%)',
                data: humidity,
                borderColor: '#1a75ff',
                backgroundColor: ' #0066ff',
                borderWidth: 1
            },
        ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
 }
 
// document.getElementById('dailySubmit').addEventListener('click', async function() {
//     const city = document.getElementById('city').value;
//     const days = document.getElementById('days').value;
//     const dailyWeatherResult = document.getElementById('daily-weather-result');
//     dailyWeatherResult.innerHTML = '';

//     try {
//         const response = await fetch(`/dailyforecast?city=${city}&days=${days}`);
//         if (response.ok) {
//             const data = await response.json();
//             data.forecast.forecastday.forEach(day => {
//                 dailyWeatherResult.innerHTML += `
//                     <h2>Weather on ${day.date}</h2>
//                     <p>Temperature: ${day.day.avgtemp_c}°C</p>
//                     <p>Condition: ${day.day.condition.text}</p>
//                     <p>Humidity: ${day.day.avghumidity}%</p>
//                     <p>Cloud: ${day.day.avgcloud}%</p>
//                 `;
//             });
//         } else {
//             const errorText = await response.text();
//             dailyWeatherResult.innerHTML = `<p>Failed to fetch daily weather data: ${errorText}</p>`;
//         }
//     } catch (error) {
//         console.error('Error fetching daily weather data:', error);
//         dailyWeatherResult.innerHTML = `<p>Error fetching daily weather data: ${error.message}</p>`;
//     }
// });
document.getElementById('hourlySubmit').addEventListener('click', async function() {
    const city = document.getElementById('city').value;
    const hours = document.getElementById('hours').value; 
    const historyWeatherResult = document.getElementById('hourly-weather-result');
    const errorDiv = document.getElementById('error');

    historyWeatherResult.innerHTML = '';
    errorDiv.innerHTML = '';

    try {
        const response = await fetch(`/hourlyforecast?city=${city}&days=1`);
        if (response.ok) {
            const data = await response.json();
            data.forecast.forecastday.forEach(day => {
                for (let i = 0; i < hours && i < day.hour.length; i++) {
                    const hourData = day.hour[i];
                    historyWeatherResult.innerHTML += `
                        <h3>Weather at ${hourData.time}</h3>
                        <p>Temperature: ${hourData.temp_c}°C</p>
                        <p>Wind Speed: ${hourData.wind_kph} kph</p>
                        <p>Humidity: ${hourData.humidity}%</p>
                    `;
                }
            });
        } else {
            const errorText = await response.text();
            errorDiv.innerHTML = `<p>Failed to fetch historical weather data: ${errorText}</p>`;
        }
    } catch (error) {
        console.error('Error fetching historical weather data:', error);
        errorDiv.innerHTML = `<p>Error fetching historical weather data: ${error.message}</p>`;
    }
});



document.getElementById('alertSubmit').addEventListener('click', async function() {
    const city = document.getElementById('city').value;
    const days = document.getElementById('days').value;
    const alerts = document.getElementById('alerts').value;
    const alertWeatherResult = document.getElementById('alert-weather-result');
    const errorDiv = document.querySelector('.error');
    alertWeatherResult.innerHTML = '';
    errorDiv.innerHTML = '';

    try {
        const response = await fetch(`/alerts?city=${city}&days=${days}&alerts=${alerts}`);
        if (response.ok) {
            const data = await response.json();
            if (data.alerts && data.alerts.length) {
                data.alerts.forEach(alert => {
                    alertWeatherResult.innerHTML += `
                        <h2>Alert: ${alert.headline}</h2>
                        <p>Description: ${alert.description}</p>
                        <p>Instructions: ${alert.instruction}</p>
                    `;
                });
            } else {
                alertWeatherResult.innerHTML = '<p>No alerts available for the selected criteria.</p>';
            }
        } else {
            const errorText = await response.text();
            errorDiv.innerHTML = `<p>Failed to fetch alert weather data: ${errorText}</p>`;
        }
    } catch (error) {
        console.error('Error fetching alert weather data:', error);
        errorDiv.innerHTML = `<p>Error fetching alert weather data: ${error.message}</p>`;
    }
});

document.getElementById('historySubmit').addEventListener('click', async function() {
    const city = document.getElementById('city').value;
    const date = document.getElementById('dt').value;
    const historyWeatherResult = document.getElementById('history-weather-result');
    const errorDiv = document.querySelector('.error');
    historyWeatherResult.innerHTML = '';
    errorDiv.innerHTML = '';

    try {
        const response = await fetch(`/history?city=${city}&date=${date}`);
        if (response.ok) {
            const data = await response.json();
            if (data.forecast && data.forecast.forecastday.length > 0) {
                const hours = data.forecast.forecastday[0].hour;
                const hoursHtml = hours.map(hourData => `
                    <div class="hourly-weather">
                        <h3>Weather at ${hourData.time}</h3>
                        <p>Temperature: ${hourData.temp_c}°C</p>
                        <p>Wind Speed: ${hourData.wind_kph} kph</p>
                        <p>Humidity: ${hourData.humidity}%</p>
                        <p>Condition: ${hourData.condition.text}</p>
                        <img src="${hourData.condition.icon}" alt="${hourData.condition.text}">
                    </div>
                `).join('');
                historyWeatherResult.innerHTML = hoursHtml;
            } else {
                historyWeatherResult.innerHTML = '<p>No historical data available.</p>';
            }
        } else {
            const errorText = await response.text();
            errorDiv.innerHTML = `<p>Failed to fetch historical weather data: ${errorText}</p>`;
        }
    } catch (error) {
        console.error('Error fetching historical weather data:', error);
        errorDiv.innerHTML = `<p>Error fetching historical weather data: ${error.message}</p>`;
    }
});





