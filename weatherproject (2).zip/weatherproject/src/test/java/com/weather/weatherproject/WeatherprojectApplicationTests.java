package com.weather.weatherproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
