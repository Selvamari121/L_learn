/*let fruit=["apple","orange","mango","red banana"];
for(let fruits of fruit){
   console.log(fruits);
}*/


/*let order=["control","save","copy","paste","all","undo","run"];
order.sort();
for(let orderWise of order){
  console.log(orderWise);
}*/

/*let order=["control","save","copy","paste","all","undo","run"];
order.sort().reverse();
for(let orderWise of order){
  console.log(orderWise);
}*/


/*let fruits=["apple","orange","mango"];
let veg=["corret","potato","onion"];
//let food=fruits.concat(veg);
let food=[...fruits, ...veg,"red banana"];
console.log(food);*/

/*function openFrige(...food){
     console.log(food);
}
const food1="pitzza";
const food2="burger";
const food3="french fries";
const food4="hotdog";

openFrige(food1,food2,food3,food4);*/

/*function sum(...numbers){
   let result=0;
   for(let number of numbers){
      result=result+number;
   }
   return result;
}
const count=sum(1,2,3,4,5,6);
console.log(count);
*/
