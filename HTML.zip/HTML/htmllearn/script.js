/*console.log('hello world');
console.log('welcome to all');
window.alert('hi')


document.getElementById('myh1').textContent="Hi";
document.getElementById("myh1").style.color="green";

document.getElementById('mypara').textContent="good morning";
document.getElementById('mypara').style.color="red";


let firstName="selva";
let lastName="mari";
let fullName=firstName+" "+lastName;
let emailId="selvamari@gmail.com";
console.log(typeof firstName);
console.log(typeof lastName);
console.log(`your email is ${emailId}`);
console.log(`your fullname is ${fullName}`);


document.getElementById('para').textContent=fullName;
document.getElementById("head").textContent=`your full name is ${fullName}`;

*/


/*let students=31;
students=students + 6;
console.log(students);
let value=5;
value= value*5;
console.log(value);*/

/*let x=20;
let y=45;
let z;
z=x+y;
console.log(z);
x=x+3;
console.log(x);
y+=10;
console.log(y);
*/
//let result=5+7+20;
//console.log(result);
 
/*let result=5+(5-3)+87*67;
console.log(result);*/


/*let username;
username=window.prompt('what is your name?');
console.log(username);*/


/*let username;
document.getElementById('mySubmit').onclick=function(){
   username=document.getElementById('myText').value;
   //console.log(username);
  // document.getElementById('myH1').textContent=username;
  document.getElementById('myH1').textContent=`welcome back ${username}`;
}
*/


/*let age=window.prompt("how old are you?");
//age+=5;
age=Number(age);
age+=5;
console.log(age, typeof age) ;
*/


/*let x="hello";
let y="hello";
let z="hello";
x=Number(x);
y=String(y);
z=Boolean(z);
console.log(x, typeof x);
console.log(y, typeof y);
console.log(z, typeof z);*/

/*
console.log(Math.PI);
console.log(Math.E);

let x=5;
let y=3;
let z;
//z=Math.round(x+y);
//z=Math.floor(x);
//z=Math.pow(x,y);
z=Math.sqrt(x);
console.log(z);*/


/*let x=Math.floor(Math.random()*56);
console.log(x);*/

