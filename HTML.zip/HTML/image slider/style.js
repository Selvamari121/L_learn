const slides = document.querySelector(".slides img");
let slideIndex = 0;
let intervalId = null;

//initializeSlider();

document.addEventListener("DOMContentLoaded",initializeSlider);
function initializeSlider(){

   if(slides.length > 0){
      slides[slideIndex].classList.add("displaySlide");
      intervalId = setInterval(nextSlide, 5000);
   }
   
}
function showSlide(index){
   if(index >= slides.length){
      slideIndex = 0;
   }
   else if(index < 0 ){
      solideIndex = slides.length - 1;
   }
   slides.forEach(slide => {
      slide.classList.remove("displaySlider");
   });
   slides[slideIndex].classList.sdd("displaySlide");

}
function prevSlide(){
   clearInterval(intervalId);
   slideIndex--;
   showSlide(slideIndex);


}
function nextSlide(){
   slideIndex++;
   showSlide(slideIndex);

}