let slideIndex = 0;
showSlides(slideIndex);

function showSlides(index) {
  const slides = document.getElementsByClassName("slide");
  
  // Wrap around
  if (index >= slides.length) {
    slideIndex = 0;
  }
  if (index < 0) {
    slideIndex = slides.length - 1;
  }

  // Hide all slides
  for (let i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }

  // Show the selected slide
  slides[slideIndex].style.display = "block";
}

function nextSlide() {
  showSlides(++slideIndex);
}

function prevSlide() {
  showSlides(--slideIndex);
}
