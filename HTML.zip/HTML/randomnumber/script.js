/*let randomnum;
document.getElementById('myBtn').onlick=function(){
   randomnum=Math.floor(Math.random()*100);
   document.getElementById('myLabel').textContent=randomnum;
   
}*/
//console.log("helloworld");




/*let username="";
while(username===""||username===null){
   username=window.prompt("enter your name");
}
console.log(`welocome back ${username}`);*/

/*let loggedIn=false;
let username;
let password;
while(!loggedIn){
   username=window.prompt('Enter your name');
   password=window.prompt('Enter your password');
   if(username==="username"&& password==="password"){
      loggedIn=true;
      console.log("you are logged in!");
   }
   else{
      console.log("Invalid credentials! please try again");
   }
   }*/

   /*for(let i=0;i<=10;i+=2){
      console.log(i);

   }*/


     /* function myfunction(){
         console.count("hello world");
         console.count("this");
         console.count("is");
         console.count("javascript");
      }
      myfunction();
      */

     /* function myfunction(username,age)
      {
         console.log(`welcome ${username}`);
         console.log(`your age is ${age}`);
      }

      myfunction("selva",23);
      */


/*function addition( x, y){
      return x+y;
}
console.log(addition(45+655));
*/

/*function isEven(number){
   if(number%2===0){
      return true;

   }
   else{
      return false;

   }
 
}
console.log(isEven(18));
*/

/*function isEven(number){
   return number%2===0 ? true:false;
}
console.log(isEven(7));*/

/*function validation(email){
   if(email.includes("@") && email.includes(".")){
      return true;
   }
   else{
      return false;
   }

}
console.log(validation("selva@gmail.com"));
console.log(validation("selvagmailcom"));
*/

//variable scope

function1(5,6);
function function1(x,y){
 //var x=10;
// var y=10;
 console.log(x+y);
}



