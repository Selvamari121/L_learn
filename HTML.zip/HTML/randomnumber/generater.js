function generatePassword(length,includeLowerCase,includeUpperCase,includeNumber,includeSymbols){

  const lowerCaseChar="abcdefghijklmnopqrstuvwxyz";
  const upperCaseChar="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const numberChar="0123456789";
  const symbolChar="!@#$%^&*()_+-=[]{}";

  let allowedChar="";
  let password="";

  allowedChar+=includeLowerCase ? lowerCaseChar:"";
  allowedChar+=includeUpperCase ? upperCaseChar:"";
  allowedChar+=includeNumbers ? numberChar:"";
  allowedChar+=includeSymbols ? symbolChar:"";

  if(length<=0){
   return `(password length must be at least 1)`;
  }
  if(allowedChar.length === 0){
   return `(password must contain at least one character)`;
  }
  for(let i=0; i<length; i++){
   const randomIndex =Math.floor(Math.random() * allowedChar.length);
   password += allowedChar[randomIndex]
  }
 // console.log( allowedChar);

  return password;
}
const passwordLength=12;
const includeLowerCase=true;
const includeUpperCase=true;
const includeNumbers=true;
const includeSymbols=true;

const password=generatePassword(passwordLength,includeLowerCase,includeUpperCase,includeSymbols,includeNumbers);
console.log(`Generate Password:${password} `);
