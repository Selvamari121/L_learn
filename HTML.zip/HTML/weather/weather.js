document.querySelector('.weatherForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const city = document.querySelector('.cityInput').value;
    if (city) {
        fetchWeather(city);
    } else {
        displayError('Please enter a city');
    }
});

function fetchWeather(city) {
    const apiKey = '16245f9eacbd7f4475708a2fa41eeeb3';
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=imperial`;

    fetch(url)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                displayWeather(data);
            } else {
                displayError(data.message);
            }
        })
        .catch(() => {
            displayError('Unable to fetch weather data');
        });
}

function displayWeather(data) {
    document.querySelector('.cityDisplay').textContent = data.name;
    document.querySelector('.tempDisplay').textContent = `${data.main.temp}°F`;
    document.querySelector('.humidityDisplay').textContent = `Humidity: ${data.main.humidity}%`;
    document.querySelector('.descDisplay').textContent = data.weather[0].description;
    document.querySelector('.weatherEmoji').textContent = getWeatherEmoji(data.weather[0].main);
    document.querySelector('.card').style.display = 'block';
    document.querySelector('.errorDisplay').textContent = '';
}

function displayError(message) {
    document.querySelector('.errorDisplay').textContent = message;
    document.querySelector('.card').style.display = 'none';
}

function getWeatherEmoji(description) {
    const weatherConditions = {
        Clear: '☀️',
        Clouds: '☁️',
        Rain: '🌧️',
        Drizzle: '🌦️',
        Thunderstorm: '⛈️',
        Snow: '❄️',
        Mist: '🌫️'
    };
    return weatherConditions[description] || '';
}
