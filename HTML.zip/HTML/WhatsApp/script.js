function sendMessage() {
   const input = document.getElementById('message-input');
   const messageText = input.value.trim();
   if (messageText === '') return;

   const messageContainer = document.getElementById('chat-messages');
   const messageElement = document.createElement('div');
   messageElement.classList.add('message', 'sent');
   messageElement.textContent = messageText;

   messageContainer.appendChild(messageElement);
   input.value = '';
   messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Example of receiving a message
function receiveMessage(text) {
   const messageContainer = document.getElementById('chat-messages');
   const messageElement = document.createElement('div');
   messageElement.classList.add('message', 'received');
   messageElement.textContent = text;

   messageContainer.appendChild(messageElement);
   messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Simulate receiving a message
setTimeout(() => {
   receiveMessage('Hello! How can I help you?');
}, 2000);
