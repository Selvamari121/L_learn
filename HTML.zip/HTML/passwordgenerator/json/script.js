//const names = ["selva","kani","gopal","sakthi","raja"]

//const jsonString = JSON.stringify(names);
//console.log(jsonString);

/*const name = ["selva","sakthi","kani","gopal","raja"];
const person={
   "name":"Selva",
   "age":30,
   "isEmployed":true,
   "hobies":["sleeping","cooking","editing"]
}
const people=[{
   "name":"Selva",
   "age":30,
   "isEmployed":true
},
{
   "name":"Sakthi",
   "age":35,
   "isEmployed":true
},
{
   "name":"kani",
   "age":68,
   "isEmployed":true
},
{
   "name":"gopal",
   "age":33,
   "isEmployed":true
},{
   "name":"raja",
   "age":37,
   "isEmployed":true
}]
const jsonString = JSON.stringify(people);
console.log (jsonString);*/

/*fetch("people.json")
.then(response => response.json())
.then(values => values.forEach(value => console.log(value.isEmployed)));*/

fetch("https://pokeapi.co/api/v2/pokemon/pikachu");
.then(response => response.json())
.then(values => values.forEach(value => console.log(value.isEmployed)));