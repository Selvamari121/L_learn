let timeoutId;
function setTimer(){
   timeoutId = setTimeout(()=> window.alert("hello"),2000);
   console.log("started");
}
function clearTimer(){
   clearTimeout(timeoutId);
   console.log("cleared");
}