/*hello(wait);
function wait(){
   console.log("coll!");
}

let numbers =[1,2,3,4,5];
numbers.forEach(double);
//numbers.forEach(display);

function display(element){
   console.log(element);
}

function double(element, index,array){
   array[index]=element*2;
 }*/

/*   const numbers=[1,2,3,4,5];
   const squares=numbers.map(square);

   function square(element){
      return Math,pow(element ,2)
      
   }
      */ 

   //filter function

 /* let numbers = [1,2,3,4,5,6,7,];
   let evenNums = numbers.filter(isEven);
   let oddNums = numbers.filter(isOdd);
   console.log(evenNums);
   
   function isOdd(element){
    return element % 2 !==0;
   }
   function isEven(element){
      return element % 2 ==0;
     }*/

/*
      const age =[20,50,49,87,64,65,34,12,13,5,11,17];
      const adults =age.filter(isAdult);
      const children=age.filter(isChild);


      console.log(adults);

      function isAdult(element){
         return element>=18;

      }
      function isChild(element){
         return element<18;

      }*/
   
         //reduce function

       /* const grades=[56,88,76,65,98,52,43];

         const maximum = grades.reduce(getMax);
         const minimum = grades.raduce(getMin);
         console.log(maximum);
         console.log(minimum);

         function getMax(accumulator, element){
            return Math.max(accumulator, element);
         }
         function getMin(accumulator, element){
            return Math.min(accumulator, element);
         }
            */

/* map function
function declaration
         const numbers=[1,2,3,4,5,6,7,8,9];
         const squares=numbers.map(square);
         const cubes=numbers.map(cube);
         console.log(squares);
         console.log(cubes);

         function square(element){
            return Math.pow(element,2);

         }
         function cube(element){
            return Math.pow(element,3);
         }
         */

         //function expression

         
        /* const numbers=[1,2,3,4,5,6,7,8,9];
         const squares=numbers.map(function square(element){
            return Math.pow(element,2);

         });
         console.log(squares);
         const cubes=numbers.map(square);
         console.log(cubes);
         */
    //normal function
       /*  function hello(){
            console.log("hello");
         }
         hello();*/

         //arrow function
     /*    const hello=function(){
            console.log("hello");
         }
         hello();

         const  hi = () =>console.log("welcome to all");
         hi();  */

    /* const hello=(userName,age) =>{
      console.log(`i am ${userName} i am ${age} years old. `);

     }
     hello("selva",23);*/

    /* setTimeout(hello,3000);  //normal function call
     function hello(){
      console.log("Hello");
     }

     setTimeout(function (){  //function expression
      console.log("Hello");
     },3000);

     setTimeout(()=> console.log("Hello"),3000);//arrow function
*/
/*
const numbers=[1,2,3,4,5,6,7,8];
const square= numbers.map((element) => Math.pow(element,2));
const cubes = numbers.map((element) => Math.pow(element,3));
const evenNums = numbers.filter((element) => element % 2 == 0);
const oddNums = numbers.filter((element) => element % 2 !== 0);
const total = numbers.reduce((accumulator, element)=> accumulator+element);
console.log(square);
console.log(cubes);
console.log(evenNums);
console.log(oddNums);
console.log(total);*/


//object
/*const person ={
   firstName:"selvamari",
   lastName:"Sudalaimuthu",
   age:23,
   genter:"female",
   selfIntro:function(){
      console.log("hello i am selvamari iam from poolankulam. i have completed my BE from sardar raja college of ingineering.") },
   }

console.log(person);
console.log(person.firstName);

person.selfIntro();
*/


//object this keyword
/* 
const person1 ={
   name:"selva",
   favFood:"biriyani",
   sayhello:function(){
      console.log("hello i am "+this.name+" i like "+this.favFood);
      console.log(`hello i am ${this.name} love this food ${this.favFood}`);
      
   }
}
person1.sayhello();*/

//constructor


/*class carDetails {
   constructor(make, model, year, color) {
      this.make = make,
         this.model = model,
         this.year = year,
         this.color = color;
   }
}
   const car = new carDetails("chennai","bmw",2024,"red");
   console.log(carDetails);  
   */

   //constructer

  /* function car(make,model,year,color){
      this.make = make,
      this.model = model,
      this.year = year,
      this.color = color;
      this.drive = function(){console.log
         (`you model the ${this.model}
            You year the ${this.year}
            You color the ${this.color}`)}

   }
   const car1 =new car("ford","mustang",2024,"red");
   const car2 =new car("hford","hmustang",2024,"hred");
   const car3 =new car("gford","gmustang",2024,"gred");
   const car4 =new car("nford","nmustang",2024,"nred");

   car1.drive();
   car2.drive();
   car3.drive();

*/


/* class

   class product{
      constructor(name,price){
         this.name =name;
         this.price = price;
      }
      displayProduct(){
         console.log(`product: ${this.name}`);
         console.log(`price: $${this.price}`);

      }
   }
   const product1 = new product("shirt",19.99);
   const product2 = new product("pants",29.99);

   product1.displayProduct();*/



  /* function product(name,price){
      this.name=name;
      this.price=price;
      this.displayProduct = function(){
         console.log(`Product: ${this.name}`);
         console.log(`$${this.price.toFixed(2)}`);

      };
      this.calculateTotal = function(salesTex){
         return this.price + (this.price *salesTax);
      }
   }
   const salesTax = 0.05;
   const product1 = new product("Shirt",19.99);
   const product2 = new product("Pants",29.99);
   const product3 = new product("Shoes",59.99);

   product1.displayProduct();

   const totalPrice = product1.calculateTotal(salesTax);
   console.log(`Total price(with tax): $${totalPrice.toFixed(2)}`);
   */

/* static   
class MathUtil{
   static PI = 3.1415;
   static getDiameter(radius){
      return radius*2;

   }
   static getCircumfeence(radius){
      return 2*this.PI * radius;

   }
   static getArea(radius){
      return this.PI*radius*radius;
   }
}
console.log(MathUtil.PI);
console.log(MathUtil.getDiameter(5));
console.log(MathUtil.getCircumfeence(10));
*/

/*
class User{
   static userCount =0;
   constructor(username,age){
      this.username=username;
      this.age=age;
      User.userCount++;
   }
}
const user1 = new User("spongebob",97);
const user2 = new User("patrick",56)

console.log(`There are ${User.userCount} user in system.`);*/

//inheritance
/*
class Animal{
   alive =true;
   eat(){
      console.log(`This ${this.name} is eating`);
   }
   sleep(){
      console.log(`This ${this.name} is sleeping`);
   }
}
class Rabbit extends Animal{
   name = "rabbit";
}
class dog extends Animal{
   name = "dog";
}

const rabbit =new Rabbit();
//const dog = new dog();

rabbit.eat();
rabbit.sleep();
*/
//super key
/*
class Animal{
   constructor(name,age){

   }
}
class Dog extends Animal{
    constructor(name,age,runningspeed){
      super(name,age);
    }
}
class Cat extends Animal{
   constructor(name,age,flex){
     super(name,age);
   }
}
const dog =new Dog("dom",5,2334);
console.log(dog.name);*/


//getter,setter,vaalidate



/*
class Rectangle{
   constructor(width,height){
      this.width = width;
      this.height=height;

     
   }
  
   //@param {number} newWidth
  
   set width(newWidth){
      if(newWidth>0){
         this._width = newWidth;
      }
      else{
         console.error("Width must be a positive number");
      }
   }
   // @param {number} newHeighth
   
   set height(newHeighth){
      if(newHeighth>0){
         this._height= newHeighth;
      }
      else{
         console.error("height is must be a number");
      }
   }
}
const rectangle = new Rectangle(87,76);
rectangle.width =5;
rectangle.height =6;
console.log(rectangle.width);
console.log(rectangle.height);*/


//destructuring


/*const colors=["red","green","blue","black"];
[colors[0],colors[2]]=[colors[2],colors[0]];
console.log(colors);*/

//nested object
/*
const person = {
   fullname:"selva",
   age:25,
   address:{
      city:"chennai",
      state:"tamilnadu",
   }

}
console.log(person.address.city);*/

//fruits object

/*const fruits = [{fname:"apple",color:"red",calories:98},
   {fname:"orange",color:"orange",calories:986},
   {fname:"mango",color:"yellow",calories:98987}];
   console.log(fruits[2].color);
   fruits.push({fname:"banana",color:"yellow",calories:45});
   console.log(fruits);
   fruits.pop();
   console.log(fruits);
   //forEach
   fruits.forEach(fruit => console.log(fruit.color));
   //map()
   const fruitName = fruits.map(fruit => fruit.color);
   console.log(fruitName);
   //filter()
   const yellowFruits=fruits.filter(fruit => fruit.color === "yellow");
   console.log(yellowFruits);
   //reduce()
   const maxFruit = fruits.reduce((max,fruit)=>fruit.calories > max.calories ? fruit:max);
   console.log(maxFruit);
   //sort
   fruits.sort((a,b)=> b.calories-a.calories);
   console.log(fruits);
   */
  //sort()
   /*let numbers = [1,2,3,4,5,6,7,8,9];
   numbers.sort((a,b) => a-b);
   console.log(numbers);
   */

//Fisher-Yates algorithm
//cards game use 

/*const card = ['A',2,3,4,5,6,7,8,9,10,"J","Q","K"];
shuffle(card);
console.log(card);
function shuffle(array){
   for(let i=array.length -1;i>0;i--){
      const random =Math.floor(Math.random()*(i+1));
   [array[i],array[random]] =[array[random],array[i]];
   }
   

}*/

//local time
/*const date = new Date();
const year = date.getFullYear();
console.log(year);
const month =date.getMonth();
console.log(month);*/
 
//set time
/*const date = new Date();
date.setFullyear(2020);
date.setDate(9);
console.log(date);
*/


//closure =function inside another function

/*function outer(){
   let message ="hello";
   let fname="selva";
   function inner(){
      console.log(message);
   }
   inner();
   function First(){
      console.log(fname);
   }
   First();
}
outer();
*/

//setTimeout(callback, delay);

/*function sayhi(){
   console.log("hello");
}
setTimeout(sayhi,2000);
setTimeout(function(){window.alert("hello world")});
setTimeout(()=> window.alert("welcome to all"));
*/

//ES6 reusable code
//normal
/*const PI = 3.14;
function getCircumferece(radius){
   return 2*PI*radius;
}
function getArea(radius){
   return radius*PI*radius;
}
function getVolume(radius){
   return 4*PI*radius*radius;
}

//es6
import {PI, getCircumference,getArea,getVolue} from '.mathUtil.js';
const circumference = getCircumference(10);
const area =getArea(10);
const volume  = getVolume(10);
console.log(`${circumference.toFixed(2)}cm`);
console.log(`${area.toFixed(2)}cm 2`);
console.log(`${volume.toFixed(2)}cm 3`);
*/


//Error handling
/*
try{
   console.log(x); //"hello"
   //undifind error
}
catch(error){
   console.log(error.message);
   //error message
}
finally{
   console.log("this always executes");

}
console.log("you have reached the end");
*/

/*try{
   const dividend = Number(window.prompt("Enter a dividend:"));
   const divisor = Number(window.prompt("Enter a divisor:"));

   if(divisor == 0){
      throw new Error("Divisor cannot be zero");
   }
   if(isNaN(dividend) || isNaN(divisor)){
      throw new Error("Values must be a number");

   }
   const result = dividend/divisor;
   console.log(result);

}
catch(error){
   console.log("error");
}
console.log("you have reached the end!");*/
/*
document.title = "my website";
document.body.style.backgroundColor = "hsl(0,0%,15%";

console.dir(document);*/


/*const heading =document.getElementById('head');
heading.style.color="red";
heading.style.backgroundColor="black";

const para = document.getElementsByClassName('fruits');
para[0].style.color="blue";
Array.from(para).forEach(fruit => {
   para.style.backgroundColor="yellow";
});
const head=document.getElementsByTagName("h4");
const list=document.getElementsByTagName("li");
head.style.color="green";
Array.from(list).forEach(list =>{
   list.dtyle.backgroundColor="blue";
})*/

//event time
/*const myBox= document.getElementById('myBox');

myBox.addEventListener("click",event => {
event.target.style.backgroundColor = "red";
event.target.textContent ="I miss you 💜";
});
myBox.addEventListener("mouseover",event => {
   event.target.style.backgroundColor = "yellow";
   event.target.textContent ="I hate you 💛";

   });

   myBox.addEventListener("mouseout",event => {
      event.target.style.backgroundColor = "blue";
      event.target.textContent ="don't go 🧡";
      });*/

     /* 
      // button
      //img
     
     const myButton = document.getElementById("myButton");
      const myImg = document.getElementById("myImg");
      myButton.addEventListener("click",event =>{

         if(myImg.style.display ==="none"){
            myImg.style.display ="block";
            myButton.textContent ="Hide";
         }
        else{
         myImg.style.display = "none";
         myButton.textContent ="Show";
        }
      });*/

   /*

   //img
   //btn
      const myButton = document.getElementById("myButton");
      const myImg = document.getElementById("myImg");
      myButton.addEventListener("click",event =>{

         if(myImg.style.visibility ==="hidden"){
            myImg.style.visibility ="visible";
            myButton.textContent ="Hide";
         }
        else{
         myImg.style.display = "hidden";
         myButton.textContent ="Show";
        }
      });
      */
     let buttons = document.querySelectorAll(".myBtns");
    /* buttons.forEach(button => {
      //button.style.backgroundColor="green";
      //button.textContent+="😀";
      button.addEventListener("click",event => {
         event.target.style.backgroundColor="green";
      })
     });*/
    /* buttons.forEach(button => {
      button.addEventListener("mouseover", event => {
         event.target.style.backgroundColor="rad";
      });
     })
     buttons.forEach(button => {
      button.addEventListener("mouseout", event => {
         event.target.style.backgroundColor="green";
      });
     })*/

      //callback hell

      /*function task1(){
         setTimeout(() =>{
            console.log("task 1 complete");
           },4000);
      }
      function task2(){
         setTimeout(() => {
            console.log("task 2 complete");
         },5000);
      }
      function task3(){
         setTimeout(() =>{
            console.log("task 3 complete");
         },2000);

      }
      function task4(){
         setTimeout(() =>{
            console.log("task 4 complete");
         },1000);
      }
      task1();
      task2();
      task3();
      task4();
      console.log("all task finise.")*/

     // callback hell advance

     function task1(callback){
      setTimeout(() =>{
         console.log("task 1 complete");
         callback();
      })
     }
     function task2(callback){
      setTimeout(() =>{
         console.log("task 2 complete");
         callback();
      })
     }
     function task3(callback){
      setTimeout(() =>{
         console.log("task 3 complete");
         callback();
      })
     }
     function task4(callback){
      setTimeout(() =>{
         console.log("task 4 complete");
         callback();
      })
     }
     task1(() =>{
      task2(() => {
         task3(() =>{
            task4(() => console.log("All task complete."))
         })
      })
     });




     