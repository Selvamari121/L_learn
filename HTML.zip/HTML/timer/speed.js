// stop.js

let timer;
let hours = 0;
let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let isRunning = false;

const clock = document.getElementById('clock');

function updateClock() {
    let h = hours < 10 ? '0' + hours : hours;
    let m = minutes < 10 ? '0' + minutes : minutes;
    let s = seconds < 10 ? '0' + seconds : seconds;
    let ms = milliseconds < 10 ? '0' + milliseconds : milliseconds < 100 ? '0' + milliseconds : milliseconds;
    clock.textContent = `${h}:${m}:${s}:${ms}`;
}

function startTimer() {
    if (!isRunning) {
        isRunning = true;
        timer = setInterval(() => {
            milliseconds += 10;
            if (milliseconds >= 1000) {
                milliseconds = 0;
                seconds++;
            }
            if (seconds >= 60) {
                seconds = 0;
                minutes++;
            }
            if (minutes >= 60) {
                minutes = 0;
                hours++;
            }
            updateClock();
        }, 10);
    }
}

function stopTimer() {
    clearInterval(timer);
    isRunning = false;
}

function resetTimer() {
    clearInterval(timer);
    isRunning = false;
    hours = 0;
    minutes = 0;
    seconds = 0;
    milliseconds = 0;
    updateClock();
}

// Initialize clock
updateClock();

// For demonstration purposes, auto-start the timer
startTimer();

// Stop the timer after 10 seconds
setTimeout(stopTimer, 10000);

// Reset the timer after 12 seconds
setTimeout(resetTimer, 12000);







// stop.js

/*let timer;
let hours = 0;
let minutes = 0;
let seconds = 0;
let milliseconds = 0;
let isRunning = false;

const clock = document.getElementById('clock');

function updateClock() {
    let h = hours < 10 ? '0' + hours : hours;
    let m = minutes < 10 ? '0' + minutes : minutes;
    let s = seconds < 10 ? '0' + seconds : seconds;
    let ms = milliseconds < 10 ? '0' + milliseconds : milliseconds < 100 ? '0' + milliseconds : milliseconds;
    clock.textContent = `${h}:${m}:${s}:${ms}`;
}

function startTimer() {
    if (!isRunning) {
        isRunning = true;
        timer = setInterval(() => {
            milliseconds += 10;
            if (milliseconds >= 1000) {
                milliseconds = 0;
                seconds++;
            }
            if (seconds >= 60) {
                seconds = 0;
                minutes++;
            }
            if (minutes >= 60) {
                minutes = 0;
                hours++;
            }
            updateClock();
        }, 10);
    }
}

function stopTimer() {
    clearInterval(timer);
    isRunning = false;
}

function resetTimer() {
    clearInterval(timer);
    isRunning = false;
    hours = 0;
    minutes = 0;
    seconds = 0;
    milliseconds = 0;
    updateClock();
}

// Initialize clock
updateClock();

// For demonstration purposes, auto-start the timer
startTimer();

// Stop the timer after 10 seconds
setTimeout(stopTimer, 10000);

// Reset the timer after 12 seconds
setTimeout(resetTimer, 12000);
*/








































/*function updateClock(){
   const now = new Date();
   let hours = new.getHours();
   const meridiem = hours >= 12? "PM":"AM";
   hours = hours % 12 || 12;
   hours = hours.toString().padStart(2,0);
   const minutes = now.getMinutes().toString().padStart(2,0);
   const seconds = now.getSeconds().toString().padStart(2,0);
   const timeString = `${hours}:${minutes}:${seconds}:${meridiem}`;
   document.getElementById("clock").innerContent = timeString;

}
updateClock();
setInterval(updateClock, 1000);*/